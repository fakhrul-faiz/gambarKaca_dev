/*
  # Fix Messages RLS Policies

  1. New Policies
    - Create proper RLS policies for the messages table
    - Allow authenticated users to insert messages for their orders
    - Allow users to read messages for orders they're involved in
  
  2. Security
    - Ensure users can only send messages as themselves
    - Ensure users can only see messages for orders they're part of
*/

-- Enable RLS on messages table if not already enabled
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Allow authenticated users to insert messages for their orders" ON public.messages;
DROP POLICY IF EXISTS "Allow users to read messages for their orders" ON public.messages;

-- Create policy for inserting messages
CREATE POLICY "Allow authenticated users to insert messages for their orders"
ON public.messages FOR INSERT
TO authenticated
WITH CHECK (
  sender_id = auth.uid() AND
  EXISTS (
    SELECT 1
    FROM public.orders
    WHERE
      orders.id = order_id AND
      (orders.founder_id = auth.uid() OR orders.talent_id = auth.uid())
  )
);

-- Create policy for reading messages
CREATE POLICY "Allow users to read messages for their orders"
ON public.messages FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM public.orders
    WHERE
      orders.id = order_id AND
      (orders.founder_id = auth.uid() OR orders.talent_id = auth.uid())
  )
);

-- Create policy for updating messages (mark as read)
CREATE POLICY "Allow users to update their own messages"
ON public.messages FOR UPDATE
TO authenticated
USING (
  sender_id = auth.uid()
)
WITH CHECK (
  sender_id = auth.uid()
);

-- Create policy for admins to manage all messages
CREATE POLICY "Allow admins to manage all messages"
ON public.messages
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  )
);